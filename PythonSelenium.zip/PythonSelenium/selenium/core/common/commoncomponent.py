from core.seleniumcore.pagefactory import seleniumcommon
from selenium import webdriver
from core.databaseconnect import dbhelper
import os
import pathlib
import platform
import time
import mintotp
import pickle
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


def go_to(appname, firsttimelogin, fieldname):
    global databasedetails
    global driver
    global applicationname
    applicationname = appname
    sql = "select * from quolum_db_schema.info where applicationname = '{}'".format(appname)
    databasedetails = dbhelper.execute_select(sql)[0]

    url = databasedetails[fieldname]
    add_drivers_to_path()
    driver = webdriver.Chrome()
    driver.implicitly_wait(5)
    print("Navigating to URL: {}".format(url))
    if (firsttimelogin == False):
        driver.execute_cdp_cmd('Network.enable', {})
        for cookie in otpcookies:
            driver.execute_cdp_cmd('Network.setCookie', cookie)
        driver.execute_cdp_cmd('Network.disable', {})
    driver.get(url)


def enter_username_password(username, password):
    user_type_and_value = databasedetails['username'].split('=', 1)
    if (seleniumcommon.is_element_visible(driver, user_type_and_value[0], user_type_and_value[1])):
        global otpcookies
        user_type_and_value = databasedetails['username'].split('=', 1)
        next = databasedetails['next'].split('=', 1)
        password_type_and_value = databasedetails['password'].split('=', 1)
        seleniumcommon.type_into_element(driver, username,
                                         user_type_and_value[0], user_type_and_value[1])
        seleniumcommon.click(driver, next[0], next[1])
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((password_type_and_value[0], password_type_and_value[1])))
        seleniumcommon.type_into_element(driver, password,
                                         password_type_and_value[0], password_type_and_value[1])
        seleniumcommon.click(driver, next[0], next[1])
        otpinput = databasedetails['otp'].split('=', 1)
        if seleniumcommon.is_element_visible(driver, otpinput[0], otpinput[1]):
            currenturl = driver.current_url
            print("Current to URL: {}".format(currenturl))
            otpcookies = driver.get_cookies()
            sql = "UPDATE quolum_db_schema.info SET otpurl = '{}' WHERE applicationname = '{}';".format(currenturl,
                                                                                                        applicationname)
            dbhelper.execute_update(sql)
            seleniumcommon.stopdriver(driver)
            return True
        pininput = databasedetails['verificationpin'].split('=', 1)
        if seleniumcommon.is_element_visible(driver, pininput[0], pininput[1]):
            currenturl = driver.current_url
            print("Current to URL: {}".format(currenturl))
            otpcookies = driver.get_cookies()
            sql = "UPDATE quolum_db_schema.info SET otpurl = '{}' WHERE applicationname = '{}';".format(currenturl,
                                                                                                        applicationname)
            dbhelper.execute_update(sql)
            seleniumcommon.stopdriver(driver)
            return True
    return False


def enter_otp(otp):
    global otpcookies
    go_to(applicationname, False, 'otpurl')
    isdevicechecked = databasedetails['isdevicechecked'].split('=', 1)
    if seleniumcommon.assert_radio_is_selected(driver, isdevicechecked[0], isdevicechecked[1]) == False:
        seleniumcommon.click(driver, isdevicechecked[0], isdevicechecked[1])
    otpinput = databasedetails['otp'].split('=', 1)
    if seleniumcommon.is_element_visible(driver, otpinput[0], otpinput[1]):
        otpnext = databasedetails['otpnext'].split('=', 1)
        seleniumcommon.type_into_element(driver, otp, otpinput[0], otpinput[1])
        seleniumcommon.click(driver, otpnext[0], otpnext[1])
    pininput = databasedetails['verificationpin'].split('=', 1)
    if seleniumcommon.is_element_visible(driver, pininput[0], pininput[1]):
        next = databasedetails['next'].split('=', 1)
        # seleniumcommon.type_into_element(driver, userinput, pininput[0], pininput[1]) user input will take
        seleniumcommon.click(driver, next[0], next[1])
    homepage = databasedetails['homepage'].split('=', 1)
    homepageelement = WebDriverWait(driver, 10).until(EC.presence_of_element_located((homepage[0], homepage[1])))
    currenturl = driver.current_url
    print("Current to URL: {}".format(currenturl))
    otpcookies = driver.get_cookies()
    sql = "UPDATE quolum_db_schema.info SET homepageurl = '{}' WHERE applicationname = '{}';".format(currenturl,
                                                                                                     applicationname)
    dbhelper.execute_update(sql)
    seleniumcommon.stopdriver(driver)


def add_drivers_to_path():
    print("Adding webdrivers to path.")
    curr_file_path = pathlib.Path(__file__).parent.absolute()

    if platform.system() == 'Darwin':
        webdriver_path = os.path.join(curr_file_path, 'webdrivers', 'mac')
    elif platform.system() == 'Windows':
        webdriver_path = os.path.join(curr_file_path, 'webdrivers', 'windows')
    elif platform.system() == 'Linux':
        webdriver_path = os.path.join(curr_file_path, 'webdrivers', 'linux')
    else:
        raise Exception("Unknown platform. Unable to add webdrivers to path.")
    current_path = os.environ['PATH']
    new_path = webdriver_path + ':' + current_path
    os.environ['PATH'] = new_path


def navigatetoDestinationAndPerform(applicationname, sourcepage, destinationpage):
    sql = "select id from quolum_db_schema.info where applicationname = '{}'".format(applicationname)
    databasedetails = dbhelper.execute_select(sql)[0]
    applicationid = databasedetails['id']

    sql = "select id from quolum_db_schema.source_detination_mapper where applicationid = '{}' and source = '{}' and destination = '{}'".format(
        applicationid, sourcepage, destinationpage)
    databasedetails = dbhelper.execute_select(sql)[0]
    source_destination_id = databasedetails['id']

    sql = "select * from quolum_db_schema.action_locator where sourcemapperid = '{}' order by orderofexecution".format(
        source_destination_id)
    actions = dbhelper.execute_select(sql)
    return actiontoperform(actions)


def actiontoperform(actions):
    for action in actions:
        parent_handle = driver.current_window_handle
        if action['iscontentinnewwindow']:
            seleniumcommon.handle_window(driver, parent_handle)
        if action['pagevalidator'] is not None:
            pagetovalidate = action['pagevalidator'].split('=', 1)
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((pagetovalidate[0], pagetovalidate[1])))
        if action['action'] == 'click':
            actiontoperform = action['locator'].split('=', 1)
            if action['framelocator'] is not None:
                framelocator = action['framelocator'].split('=', 1)
                element = seleniumcommon.find_element(driver, framelocator[0], framelocator[1])
                driver.switch_to.frame(element)
                seleniumcommon.click(driver, actiontoperform[0], actiontoperform[1])
                driver.switch_to.parent_frame()
            else:
                seleniumcommon.click(driver, actiontoperform[0], actiontoperform[1])
        if action['action'] == 'fetchdata':
            fetchdata = action['locator'].split('=', 1)
            return seleniumcommon.get_element_text(driver, fetchdata[0], fetchdata[1])



if __name__ == '__main__':
    enter_otp('1234')

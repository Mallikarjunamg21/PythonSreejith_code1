
from setuptools import setup, find_packages
setup(name='Selenium',
      version='1.0',
      description='Python Selenium',
      author='Sreejith Kunchu',
      author_email='sreejithkunchu5@gmail.com',
      packages= find_packages()
     )


username = ''
password = ''
otp = ''
driver = None
data_platform_id = None
tenant_id = None
applicant_id = None
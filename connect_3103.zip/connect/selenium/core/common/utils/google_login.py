from core.common.repository import dp_applicant_login_info
from core.seleniumcore.pagefactory import seleniumcommon
from core.common.models import login_credentails_dto
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from core.common import commoncomponent
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

mfa_cookies = 'mfa_cookies'
mfa_url = 'mfa_url'


def go_to(firsttimelogin, driver, tenant_id, data_platform_id, applicant_id):
    if (firsttimelogin == False):
        applicant_login_info = dp_applicant_login_info.fetch_dp_applicant_login_info(tenant_id, data_platform_id,
                                                                                     applicant_id)
        commoncomponent.add_drivers_to_path()
        driver = webdriver.Chrome()
        driver.implicitly_wait(5)
        temp_cookies = applicant_login_info[mfa_cookies]
        cookies = eval(temp_cookies)
        driver.execute_cdp_cmd('Network.enable', {})
        for cookie in cookies:
            driver.execute_cdp_cmd('Network.setCookie', cookie)
        driver.execute_cdp_cmd('Network.disable', {})
        driver.get(applicant_login_info[mfa_url])
        windows_before = driver.window_handles[0]

        driver.execute_script("window.open()")
        driver.switch_to.window(driver.window_handles[1])
        driver.execute_cdp_cmd('Network.enable', {})
        for cookie in otpcookies:
            driver.execute_cdp_cmd('Network.setCookie', cookie)
        driver.execute_cdp_cmd('Network.disable', {})
        driver.get(currenturl)
        return driver

def enter_username_password(driver, username, password, tenant_id, data_platform_id, applicant_id):
    global next_locator
    global otpinput_locator
    global verificationpin_locator
    username_locator = "xpath=//input[@type='email']"
    next_locator = "xpath=//div[@class='VfPpkd-RLmnJb']"
    old_next_locator = "xpath=//input[@id='next']"
    password_locator = "xpath=//input[@type='password']"
    otpinput_locator = "xpath=//input[@type='tel']"

    user_type_and_value = username_locator.split('=', 1)
    if (seleniumcommon.is_element_visible(driver, user_type_and_value[0], user_type_and_value[1])):
        global currenturl
        global otpcookies
        next_type_value = next_locator.split('=', 1)
        old_next_locator_type_value = old_next_locator.split("=", 1)
        password_type_and_value = password_locator.split('=', 1)
        seleniumcommon.type_into_element(driver, username,
                                         user_type_and_value[0], user_type_and_value[1])
        if (seleniumcommon.is_element_visible(driver, next_type_value[0], next_type_value[1])):
            seleniumcommon.click(driver, next_type_value[0], next_type_value[1])
        if (seleniumcommon.is_element_visible(driver, old_next_locator_type_value[0], old_next_locator_type_value[1])):
            seleniumcommon.click(driver, old_next_locator_type_value[0], old_next_locator_type_value[1])
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((password_type_and_value[0], password_type_and_value[1])))
        seleniumcommon.type_into_element(driver, password,
                                         password_type_and_value[0], password_type_and_value[1])
        if (seleniumcommon.is_element_visible(driver, next_type_value[0], next_type_value[1])):
            seleniumcommon.click(driver, next_type_value[0], next_type_value[1])
        if (seleniumcommon.is_element_visible(driver, old_next_locator_type_value[0], old_next_locator_type_value[1])):
            seleniumcommon.click(driver, old_next_locator_type_value[0], old_next_locator_type_value[1])
        otpinput = otpinput_locator.split('=', 1)
        if seleniumcommon.is_element_visible(driver, otpinput[0], otpinput[1]):
            currenturl = driver.current_url
            print("Current to URL: {}".format(currenturl))
            otpcookies = driver.get_cookies()
            # dp_applicant_login_info.update_mfa_cookies(tenant_id, data_platform_id, applicant_id, currenturl,
            #                                            otpcookies)
            seleniumcommon.stopdriver(driver)
            return True
    return False


def enter_otp(driver, tenant_id, data_platform_id, applicant_id):
    global otpcookies
    devicechecked_locator = "xpath=//div[contains(text(),'Don’t ask again on this device')]/parent::div/preceding-sibling::div"

    driver = go_to(False, driver, tenant_id, data_platform_id, applicant_id)
    devicechecked_type_value = devicechecked_locator.split('=', 1)
    if seleniumcommon.assert_radio_is_selected(driver, devicechecked_type_value[0],
                                                devicechecked_type_value[1]) == False:
        seleniumcommon.click(driver, devicechecked_type_value[0], devicechecked_type_value[1])
    otpinput_type_value = otpinput_locator.split('=', 1)
    if seleniumcommon.is_element_visible(driver, otpinput_type_value[0], otpinput_type_value[1]):
        next_type_value = next_locator.split('=', 1)
        seleniumcommon.type_into_element(driver, input("Enter OTP received: "), otpinput_type_value[0],
                                         otpinput_type_value[1])
        seleniumcommon.click(driver, next_type_value[0], next_type_value[1])
        time.sleep(3)
        driver.switch_to.window(driver.window_handles[0])
    return driver